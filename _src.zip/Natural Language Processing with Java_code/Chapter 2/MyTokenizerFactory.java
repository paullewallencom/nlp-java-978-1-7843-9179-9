package packt;

import opennlp.tools.tokenize.TokenizerFactory;

public class MyTokenizerFactory extends TokenizerFactory {
    
}
